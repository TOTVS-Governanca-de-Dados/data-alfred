import data_alfred

data_alfred.create_project_structure()
