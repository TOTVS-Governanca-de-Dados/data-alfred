# This file is used to initialize the package

from .creator import create_project_structure

